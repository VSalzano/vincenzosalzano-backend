package com.epicode.menupizzeria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MenupizzeriaApplicationTests {

	@Test
	void contextLoads() {
	}

}
