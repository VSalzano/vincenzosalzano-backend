package com.epicode.menupizzeria;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MenupizzeriaApplication {

	public static void main(String[] args) {
		SpringApplication.run(MenupizzeriaApplication.class, args);
	}

}
